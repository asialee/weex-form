<template>
  <div>
		<Button text="确定"
				:btnStyle='btnStyle'
				@wxcButtonClicked="wxcButtonClicked"></Button>
	</div>
</template>


<style scoped>
</style>

<script>
import Button from "./components/button/index.vue";

export default {
  components: { Button },
  data() {
    return {
      btnStyle: {}
    };
  },
  methods: {
    wxcButtonClicked(e) {
      console.log(e)
    }
  }
};
</script>
